# ruleid: deprecated_calendar_iso_day_of_week_3
day_of_week = Calendar.ISO.day_of_week(year, month, day)
