# ruleid: deprecated_bnot_operator
Bitwise.bnot(2)

# ruleid: deprecated_bnot_operator
Bitwise.bnot(2) &&& 3
