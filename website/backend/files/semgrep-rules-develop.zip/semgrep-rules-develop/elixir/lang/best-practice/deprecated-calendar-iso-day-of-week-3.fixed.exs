# ruleid: deprecated_calendar_iso_day_of_week_3
{day_of_week, _, _} = Calendar.ISO.day_of_week(year, month, day, :default)
