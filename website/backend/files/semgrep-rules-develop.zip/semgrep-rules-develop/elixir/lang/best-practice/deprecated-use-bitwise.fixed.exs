# ruleid: deprecated_use_bitwise
import Bitwise
