# ruleid: atom_exhaustion
String.to_atom("dynamic")
# ruleid: atom_exhaustion
List.to_atom(~c"dynamic")
