// ruleid: clojars-api-token
clojars_api_token = "CLOJARS_qvyye3cfm6mdqhe9hjkysxiem57yb6mznbxdnx94gd62rh9q3jq7wiqyasyp"