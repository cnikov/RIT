// ruleid: bittrex-secret-key
bittrex_api_token = "kck29vz2gbqafyba2w7s44w3dkfe64at"