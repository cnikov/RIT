// ruleid: atlassian-api-token
atlassian_api_token = "fmh908q7r56qstff024d9wu1"
// ruleid: atlassian-api-token
confluence_api_token = "jpfx38t5wsrq7saj2257i6dr"