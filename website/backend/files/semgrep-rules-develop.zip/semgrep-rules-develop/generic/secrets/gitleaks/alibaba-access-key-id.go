// ruleid: alibaba-access-key-id
alibabaKey := "LTAI2b83e35d8a8482458c7b"